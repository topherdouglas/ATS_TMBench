===========================================================================
List of files contained in this ZIP file
===========================================================================
* XY Chart Buffer.vi
* XY Chart.vi --> NOTE: After unzipping, run this program.

===========================================================================
Note: This ZIP file only contains the example code and auxiliary files
      themselves, and does not contain necessary drivers nor standard
      distribution libraries.   Please make sure the standard distribution
      libraries are already on your system before running these examples.
===========================================================================
List generated on 12-27-1999 at 13:11:38
===========================================================================
